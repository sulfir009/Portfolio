<?php

class WPML_Elementor_Media_Node_Media_Carousel extends WPML_Elementor_Media_Node_With_Slides {

	protected function get_image_property_name() {
		return 'image';
	}
}
