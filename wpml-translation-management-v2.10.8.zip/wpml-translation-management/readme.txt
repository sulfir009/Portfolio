=== WPML Translation Management ===
Stable tag: 2.10.8