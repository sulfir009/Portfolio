<?php

namespace WPML\Core;

use WPML\Core\Twig\Error\LoaderError;
\class_exists('WPML\\Core\\Twig\\Error\\LoaderError');
if (\false) {
    class Twig_Error_Loader extends \WPML\Core\Twig\Error\LoaderError
    {
    }
}
