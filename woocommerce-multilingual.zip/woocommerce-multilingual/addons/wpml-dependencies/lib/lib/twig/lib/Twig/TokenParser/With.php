<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\WithTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\WithTokenParser');
if (\false) {
    class Twig_TokenParser_With extends \WPML\Core\Twig\TokenParser\WithTokenParser
    {
    }
}
