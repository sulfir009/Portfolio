<?php

namespace WPML\Core;

use WPML\Core\Twig\Lexer;
\class_exists('WPML\\Core\\Twig\\Lexer');
if (\false) {
    class Twig_Lexer extends \WPML\Core\Twig\Lexer
    {
    }
}
