<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeVisitor\NodeVisitorInterface;
\class_exists('WPML\\Core\\Twig\\NodeVisitor\\NodeVisitorInterface');
if (\false) {
    class Twig_NodeVisitorInterface extends \WPML\Core\Twig\NodeVisitor\NodeVisitorInterface
    {
    }
}
