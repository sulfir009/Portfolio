<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\ForLoopNode;
\class_exists('WPML\\Core\\Twig\\Node\\ForLoopNode');
if (\false) {
    class Twig_Node_ForLoop extends \WPML\Core\Twig\Node\ForLoopNode
    {
    }
}
