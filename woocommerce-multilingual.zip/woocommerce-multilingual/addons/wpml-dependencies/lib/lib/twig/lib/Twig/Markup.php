<?php

namespace WPML\Core;

use WPML\Core\Twig\Markup;
\class_exists('WPML\\Core\\Twig\\Markup');
if (\false) {
    class Twig_Markup extends \WPML\Core\Twig\Markup
    {
    }
}
