<?php

namespace WPML\Core;

use WPML\Core\Twig\Error\Error;
\class_exists('WPML\\Core\\Twig\\Error\\Error');
if (\false) {
    class Twig_Error extends \WPML\Core\Twig\Error\Error
    {
    }
}
