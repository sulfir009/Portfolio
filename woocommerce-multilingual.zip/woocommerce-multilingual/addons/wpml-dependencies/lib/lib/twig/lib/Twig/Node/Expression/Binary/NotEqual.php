<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\NotEqualBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\NotEqualBinary');
if (\false) {
    class Twig_Node_Expression_Binary_NotEqual extends \WPML\Core\Twig\Node\Expression\Binary\NotEqualBinary
    {
    }
}
