<?php

namespace WPML\Core;

use WPML\Core\Twig\Util\TemplateDirIterator;
\class_exists('WPML\\Core\\Twig\\Util\\TemplateDirIterator');
if (\false) {
    class Twig_Util_TemplateDirIterator extends \WPML\Core\Twig\Util\TemplateDirIterator
    {
    }
}
