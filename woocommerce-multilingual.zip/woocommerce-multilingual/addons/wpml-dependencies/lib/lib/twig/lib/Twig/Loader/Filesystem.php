<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\FilesystemLoader;
\class_exists('WPML\\Core\\Twig\\Loader\\FilesystemLoader');
if (\false) {
    class Twig_Loader_Filesystem extends \WPML\Core\Twig\Loader\FilesystemLoader
    {
    }
}
