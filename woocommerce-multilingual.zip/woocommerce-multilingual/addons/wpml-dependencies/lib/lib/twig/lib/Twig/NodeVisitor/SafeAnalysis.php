<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeVisitor\SafeAnalysisNodeVisitor;
\class_exists('WPML\\Core\\Twig\\NodeVisitor\\SafeAnalysisNodeVisitor');
if (\false) {
    class Twig_NodeVisitor_SafeAnalysis extends \WPML\Core\Twig\NodeVisitor\SafeAnalysisNodeVisitor
    {
    }
}
