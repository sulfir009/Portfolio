<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\AutoEscapeNode;
\class_exists('WPML\\Core\\Twig\\Node\\AutoEscapeNode');
if (\false) {
    class Twig_Node_AutoEscape extends \WPML\Core\Twig\Node\AutoEscapeNode
    {
    }
}
