<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Dumper\BlackfireDumper;
\class_exists('WPML\\Core\\Twig\\Profiler\\Dumper\\BlackfireDumper');
if (\false) {
    class Twig_Profiler_Dumper_Blackfire extends \WPML\Core\Twig\Profiler\Dumper\BlackfireDumper
    {
    }
}
