<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\SandboxNode;
\class_exists('WPML\\Core\\Twig\\Node\\SandboxNode');
if (\false) {
    class Twig_Node_Sandbox extends \WPML\Core\Twig\Node\SandboxNode
    {
    }
}
