<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\NameExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\NameExpression');
if (\false) {
    class Twig_Node_Expression_Name extends \WPML\Core\Twig\Node\Expression\NameExpression
    {
    }
}
