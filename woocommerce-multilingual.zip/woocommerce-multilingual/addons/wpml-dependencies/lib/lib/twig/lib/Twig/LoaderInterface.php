<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\LoaderInterface;
\class_exists('WPML\\Core\\Twig\\Loader\\LoaderInterface');
if (\false) {
	interface Twig_LoaderInterface extends \WPML\Core\Twig\Loader\LoaderInterface
    {
    }
}
