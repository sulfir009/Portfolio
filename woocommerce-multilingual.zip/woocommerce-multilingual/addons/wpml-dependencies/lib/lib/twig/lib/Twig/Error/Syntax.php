<?php

namespace WPML\Core;

use WPML\Core\Twig\Error\SyntaxError;
\class_exists('WPML\\Core\\Twig\\Error\\SyntaxError');
if (\false) {
    class Twig_Error_Syntax extends \WPML\Core\Twig\Error\SyntaxError
    {
    }
}
