<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\SetNode;
\class_exists('WPML\\Core\\Twig\\Node\\SetNode');
if (\false) {
    class Twig_Node_Set extends \WPML\Core\Twig\Node\SetNode
    {
    }
}
