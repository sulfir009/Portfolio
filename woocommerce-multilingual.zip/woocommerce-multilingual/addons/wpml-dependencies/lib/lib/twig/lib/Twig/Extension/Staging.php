<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\StagingExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\StagingExtension');
if (\false) {
    class Twig_Extension_Staging extends \WPML\Core\Twig\Extension\StagingExtension
    {
    }
}
