<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\FilterExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\FilterExpression');
if (\false) {
    class Twig_Node_Expression_Filter extends \WPML\Core\Twig\Node\Expression\FilterExpression
    {
    }
}
