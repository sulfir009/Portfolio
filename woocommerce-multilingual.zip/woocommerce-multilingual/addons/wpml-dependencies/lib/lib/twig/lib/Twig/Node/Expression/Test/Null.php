<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Test\NullTest;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Test\\NullTest');
if (\false) {
    class Twig_Node_Expression_Test_Null extends \WPML\Core\Twig\Node\Expression\Test\NullTest
    {
    }
}
