<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\DebugExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\DebugExtension');
if (\false) {
    class Twig_Extension_Debug extends \WPML\Core\Twig\Extension\DebugExtension
    {
    }
}
