<?php

namespace WPML\Core;

use WPML\Core\Twig\TwigFilter;
\class_exists('WPML\\Core\\Twig\\TwigFilter');
if (\false) {
    class Twig_SimpleFilter extends \WPML\Core\Twig\TwigFilter
    {
    }
}
