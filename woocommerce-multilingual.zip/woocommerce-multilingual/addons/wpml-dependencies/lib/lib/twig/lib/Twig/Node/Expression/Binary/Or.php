<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\OrBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\OrBinary');
if (\false) {
    class Twig_Node_Expression_Binary_Or extends \WPML\Core\Twig\Node\Expression\Binary\OrBinary
    {
    }
}
