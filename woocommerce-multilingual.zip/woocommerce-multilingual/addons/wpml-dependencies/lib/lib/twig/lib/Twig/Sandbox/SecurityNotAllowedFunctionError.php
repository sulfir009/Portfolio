<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityNotAllowedFunctionError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityNotAllowedFunctionError');
if (\false) {
    class Twig_Sandbox_SecurityNotAllowedFunctionError extends \WPML\Core\Twig\Sandbox\SecurityNotAllowedFunctionError
    {
    }
}
