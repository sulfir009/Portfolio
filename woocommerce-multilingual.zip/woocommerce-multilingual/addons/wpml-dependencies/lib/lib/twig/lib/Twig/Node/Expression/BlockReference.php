<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\BlockReferenceExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\BlockReferenceExpression');
if (\false) {
    class Twig_Node_Expression_BlockReference extends \WPML\Core\Twig\Node\Expression\BlockReferenceExpression
    {
    }
}
