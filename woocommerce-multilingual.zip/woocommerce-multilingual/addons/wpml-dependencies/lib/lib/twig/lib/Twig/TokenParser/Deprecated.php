<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\DeprecatedTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\DeprecatedTokenParser');
if (\false) {
    class Twig_TokenParser_Deprecated extends \WPML\Core\Twig\TokenParser\DeprecatedTokenParser
    {
    }
}
