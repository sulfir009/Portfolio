<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\ProfilerExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\ProfilerExtension');
if (\false) {
    class Twig_Extension_Profiler extends \WPML\Core\Twig\Extension\ProfilerExtension
    {
    }
}
