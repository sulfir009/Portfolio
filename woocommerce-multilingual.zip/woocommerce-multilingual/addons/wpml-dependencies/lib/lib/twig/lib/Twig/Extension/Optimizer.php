<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\OptimizerExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\OptimizerExtension');
if (\false) {
    class Twig_Extension_Optimizer extends \WPML\Core\Twig\Extension\OptimizerExtension
    {
    }
}
