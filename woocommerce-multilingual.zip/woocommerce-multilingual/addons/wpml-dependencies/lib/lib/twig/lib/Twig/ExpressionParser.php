<?php

namespace WPML\Core;

use WPML\Core\Twig\ExpressionParser;
\class_exists('WPML\\Core\\Twig\\ExpressionParser');
if (\false) {
    class Twig_ExpressionParser extends \WPML\Core\Twig\ExpressionParser
    {
    }
}
