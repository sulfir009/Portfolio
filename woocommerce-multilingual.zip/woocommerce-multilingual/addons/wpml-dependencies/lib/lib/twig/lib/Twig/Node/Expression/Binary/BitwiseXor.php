<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\BitwiseXorBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\BitwiseXorBinary');
if (\false) {
    class Twig_Node_Expression_Binary_BitwiseXor extends \WPML\Core\Twig\Node\Expression\Binary\BitwiseXorBinary
    {
    }
}
