<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityNotAllowedFilterError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityNotAllowedFilterError');
if (\false) {
    class Twig_Sandbox_SecurityNotAllowedFilterError extends \WPML\Core\Twig\Sandbox\SecurityNotAllowedFilterError
    {
    }
}
