<?php

namespace WPML\Core;

use WPML\Core\Twig\RuntimeLoader\RuntimeLoaderInterface;
\class_exists('WPML\\Core\\Twig\\RuntimeLoader\\RuntimeLoaderInterface');
if (\false) {
    class Twig_RuntimeLoaderInterface extends \WPML\Core\Twig\RuntimeLoader\RuntimeLoaderInterface
    {
    }
}
