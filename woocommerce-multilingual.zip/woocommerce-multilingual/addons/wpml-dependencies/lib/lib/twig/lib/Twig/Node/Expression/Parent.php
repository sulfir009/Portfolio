<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\ParentExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\ParentExpression');
if (\false) {
    class Twig_Node_Expression_Parent extends \WPML\Core\Twig\Node\Expression\ParentExpression
    {
    }
}
