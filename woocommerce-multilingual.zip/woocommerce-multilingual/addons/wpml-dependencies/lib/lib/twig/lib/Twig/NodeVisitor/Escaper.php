<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeVisitor\EscaperNodeVisitor;
\class_exists('WPML\\Core\\Twig\\NodeVisitor\\EscaperNodeVisitor');
if (\false) {
    class Twig_NodeVisitor_Escaper extends \WPML\Core\Twig\NodeVisitor\EscaperNodeVisitor
    {
    }
}
