<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\PrintNode;
\class_exists('WPML\\Core\\Twig\\Node\\PrintNode');
if (\false) {
    class Twig_Node_Print extends \WPML\Core\Twig\Node\PrintNode
    {
    }
}
