<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityError');
if (\false) {
    class Twig_Sandbox_SecurityError extends \WPML\Core\Twig\Sandbox\SecurityError
    {
    }
}
