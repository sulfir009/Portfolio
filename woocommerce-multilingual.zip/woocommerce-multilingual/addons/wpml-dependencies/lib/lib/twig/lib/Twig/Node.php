<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Node;
\class_exists('WPML\\Core\\Twig\\Node\\Node');
if (\false) {
    class Twig_Node extends \WPML\Core\Twig\Node\Node
    {
    }
}
