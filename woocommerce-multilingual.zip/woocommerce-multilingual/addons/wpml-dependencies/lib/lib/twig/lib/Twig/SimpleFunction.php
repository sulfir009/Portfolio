<?php

namespace WPML\Core;

use WPML\Core\Twig\TwigFunction;
\class_exists('WPML\\Core\\Twig\\TwigFunction');
if (\false) {
    class Twig_SimpleFunction extends \WPML\Core\Twig\TwigFunction
    {
    }
}
