<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\IfTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\IfTokenParser');
if (\false) {
    class Twig_TokenParser_If extends \WPML\Core\Twig\TokenParser\IfTokenParser
    {
    }
}
