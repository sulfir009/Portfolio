<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\MethodCallExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\MethodCallExpression');
if (\false) {
    class Twig_Node_Expression_MethodCall extends \WPML\Core\Twig\Node\Expression\MethodCallExpression
    {
    }
}
