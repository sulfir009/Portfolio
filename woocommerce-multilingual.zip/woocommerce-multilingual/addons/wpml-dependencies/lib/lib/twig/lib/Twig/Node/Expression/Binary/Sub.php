<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\SubBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\SubBinary');
if (\false) {
    class Twig_Node_Expression_Binary_Sub extends \WPML\Core\Twig\Node\Expression\Binary\SubBinary
    {
    }
}
