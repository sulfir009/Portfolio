<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\BlockReferenceNode;
\class_exists('WPML\\Core\\Twig\\Node\\BlockReferenceNode');
if (\false) {
    class Twig_Node_BlockReference extends \WPML\Core\Twig\Node\BlockReferenceNode
    {
    }
}
