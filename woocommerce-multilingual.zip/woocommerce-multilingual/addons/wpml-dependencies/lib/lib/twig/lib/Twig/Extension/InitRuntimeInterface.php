<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\InitRuntimeInterface;
\class_exists('WPML\\Core\\Twig\\Extension\\InitRuntimeInterface');
if (\false) {
    class Twig_Extension_InitRuntimeInterface extends \WPML\Core\Twig\Extension\InitRuntimeInterface
    {
    }
}
