<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\BitwiseAndBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\BitwiseAndBinary');
if (\false) {
    class Twig_Node_Expression_Binary_BitwiseAnd extends \WPML\Core\Twig\Node\Expression\Binary\BitwiseAndBinary
    {
    }
}
