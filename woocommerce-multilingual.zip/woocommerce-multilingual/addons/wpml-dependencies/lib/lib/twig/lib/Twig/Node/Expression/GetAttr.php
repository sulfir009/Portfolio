<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\GetAttrExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\GetAttrExpression');
if (\false) {
    class Twig_Node_Expression_GetAttr extends \WPML\Core\Twig\Node\Expression\GetAttrExpression
    {
    }
}
