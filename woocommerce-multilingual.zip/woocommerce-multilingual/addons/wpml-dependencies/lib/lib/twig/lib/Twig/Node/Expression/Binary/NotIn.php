<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\NotInBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\NotInBinary');
if (\false) {
    class Twig_Node_Expression_Binary_NotIn extends \WPML\Core\Twig\Node\Expression\Binary\NotInBinary
    {
    }
}
