<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\MacroNode;
\class_exists('WPML\\Core\\Twig\\Node\\MacroNode');
if (\false) {
    class Twig_Node_Macro extends \WPML\Core\Twig\Node\MacroNode
    {
    }
}
