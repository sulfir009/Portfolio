<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Unary\NotUnary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Unary\\NotUnary');
if (\false) {
    class Twig_Node_Expression_Unary_Not extends \WPML\Core\Twig\Node\Expression\Unary\NotUnary
    {
    }
}
