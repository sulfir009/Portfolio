<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\BodyNode;
\class_exists('WPML\\Core\\Twig\\Node\\BodyNode');
if (\false) {
    class Twig_Node_Body extends \WPML\Core\Twig\Node\BodyNode
    {
    }
}
