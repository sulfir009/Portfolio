<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Dumper\BaseDumper;
\class_exists('WPML\\Core\\Twig\\Profiler\\Dumper\\BaseDumper');
if (\false) {
    class Twig_Profiler_Dumper_Base extends \WPML\Core\Twig\Profiler\Dumper\BaseDumper
    {
    }
}
