<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityPolicy;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityPolicy');
if (\false) {
    class Twig_Sandbox_SecurityPolicy extends \WPML\Core\Twig\Sandbox\SecurityPolicy
    {
    }
}
