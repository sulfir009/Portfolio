<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\AddBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\AddBinary');
if (\false) {
    class Twig_Node_Expression_Binary_Add extends \WPML\Core\Twig\Node\Expression\Binary\AddBinary
    {
    }
}
