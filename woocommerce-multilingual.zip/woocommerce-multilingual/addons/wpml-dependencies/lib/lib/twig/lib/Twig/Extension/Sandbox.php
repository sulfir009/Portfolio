<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\SandboxExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\SandboxExtension');
if (\false) {
    class Twig_Extension_Sandbox extends \WPML\Core\Twig\Extension\SandboxExtension
    {
    }
}
