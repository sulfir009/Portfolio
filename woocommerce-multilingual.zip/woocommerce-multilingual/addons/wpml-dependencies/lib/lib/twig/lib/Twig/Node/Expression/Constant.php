<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\ConstantExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\ConstantExpression');
if (\false) {
    class Twig_Node_Expression_Constant extends \WPML\Core\Twig\Node\Expression\ConstantExpression
    {
    }
}
