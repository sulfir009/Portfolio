<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\UseTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\UseTokenParser');
if (\false) {
    class Twig_TokenParser_Use extends \WPML\Core\Twig\TokenParser\UseTokenParser
    {
    }
}
