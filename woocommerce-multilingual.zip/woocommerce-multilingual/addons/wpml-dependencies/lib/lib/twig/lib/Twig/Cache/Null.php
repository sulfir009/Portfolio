<?php

namespace WPML\Core;

use WPML\Core\Twig\Cache\NullCache;
\class_exists('WPML\\Core\\Twig\\Cache\\NullCache');
if (\false) {
    class Twig_Cache_Null extends \WPML\Core\Twig\Cache\NullCache
    {
    }
}
