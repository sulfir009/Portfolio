<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\TextNode;
\class_exists('WPML\\Core\\Twig\\Node\\TextNode');
if (\false) {
    class Twig_Node_Text extends \WPML\Core\Twig\Node\TextNode
    {
    }
}
