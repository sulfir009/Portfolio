<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\SetTempNode;
\class_exists('WPML\\Core\\Twig\\Node\\SetTempNode');
if (\false) {
    class Twig_Node_SetTemp extends \WPML\Core\Twig\Node\SetTempNode
    {
    }
}
