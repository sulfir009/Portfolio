<?php

namespace WPML\Core;

use WPML\Core\Twig\RuntimeLoader\FactoryRuntimeLoader;
\class_exists('WPML\\Core\\Twig\\RuntimeLoader\\FactoryRuntimeLoader');
if (\false) {
    class Twig_FactoryRuntimeLoader extends \WPML\Core\Twig\RuntimeLoader\FactoryRuntimeLoader
    {
    }
}
