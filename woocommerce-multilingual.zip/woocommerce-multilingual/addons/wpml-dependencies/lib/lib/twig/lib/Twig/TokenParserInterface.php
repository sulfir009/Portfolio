<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\TokenParserInterface;
\class_exists('WPML\\Core\\Twig\\TokenParser\\TokenParserInterface');
if (\false) {
    class Twig_TokenParserInterface extends \WPML\Core\Twig\TokenParser\TokenParserInterface
    {
    }
}
