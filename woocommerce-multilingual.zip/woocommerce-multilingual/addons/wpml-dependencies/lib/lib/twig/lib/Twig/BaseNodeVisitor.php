<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeVisitor\AbstractNodeVisitor;
\class_exists('WPML\\Core\\Twig\\NodeVisitor\\AbstractNodeVisitor');
if (\false) {
    class Twig_BaseNodeVisitor extends \WPML\Core\Twig\NodeVisitor\AbstractNodeVisitor
    {
    }
}
