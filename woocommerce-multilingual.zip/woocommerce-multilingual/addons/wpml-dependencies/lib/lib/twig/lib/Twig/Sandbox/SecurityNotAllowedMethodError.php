<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityNotAllowedMethodError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityNotAllowedMethodError');
if (\false) {
    class Twig_Sandbox_SecurityNotAllowedMethodError extends \WPML\Core\Twig\Sandbox\SecurityNotAllowedMethodError
    {
    }
}
