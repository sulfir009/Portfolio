<?php

namespace WPML\Core;

use WPML\Core\Twig\Test\NodeTestCase;
\class_exists('WPML\\Core\\Twig\\Test\\NodeTestCase');
if (\false) {
    class Twig_Test_NodeTestCase extends \WPML\Core\Twig\Test\NodeTestCase
    {
    }
}
