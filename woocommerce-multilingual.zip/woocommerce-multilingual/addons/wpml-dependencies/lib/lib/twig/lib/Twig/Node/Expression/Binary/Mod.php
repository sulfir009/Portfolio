<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\ModBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\ModBinary');
if (\false) {
    class Twig_Node_Expression_Binary_Mod extends \WPML\Core\Twig\Node\Expression\Binary\ModBinary
    {
    }
}
