<?php

namespace WPML\Core;

use WPML\Core\Twig\Cache\FilesystemCache;
\class_exists('WPML\\Core\\Twig\\Cache\\FilesystemCache');
if (\false) {
    class Twig_Cache_Filesystem extends \WPML\Core\Twig\Cache\FilesystemCache
    {
    }
}
