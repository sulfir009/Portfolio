<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\LessEqualBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\LessEqualBinary');
if (\false) {
    class Twig_Node_Expression_Binary_LessEqual extends \WPML\Core\Twig\Node\Expression\Binary\LessEqualBinary
    {
    }
}
