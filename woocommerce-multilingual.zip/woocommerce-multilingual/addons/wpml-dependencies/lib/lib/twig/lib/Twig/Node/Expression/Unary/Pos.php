<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Unary\PosUnary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Unary\\PosUnary');
if (\false) {
    class Twig_Node_Expression_Unary_Pos extends \WPML\Core\Twig\Node\Expression\Unary\PosUnary
    {
    }
}
