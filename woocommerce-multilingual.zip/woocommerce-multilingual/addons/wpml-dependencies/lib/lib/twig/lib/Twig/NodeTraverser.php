<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeTraverser;
\class_exists('WPML\\Core\\Twig\\NodeTraverser');
if (\false) {
    class Twig_NodeTraverser extends \WPML\Core\Twig\NodeTraverser
    {
    }
}
