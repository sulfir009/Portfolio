<?php

namespace WPML\Core;

use WPML\Core\Twig\Template;
\class_exists('WPML\\Core\\Twig\\Template');
if (\false) {
    class Twig_Template extends \WPML\Core\Twig\Template
    {
    }
}
