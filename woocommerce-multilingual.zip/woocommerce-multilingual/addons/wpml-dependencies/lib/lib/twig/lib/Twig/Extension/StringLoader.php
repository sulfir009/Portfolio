<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\StringLoaderExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\StringLoaderExtension');
if (\false) {
    class Twig_Extension_StringLoader extends \WPML\Core\Twig\Extension\StringLoaderExtension
    {
    }
}
