<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityPolicyInterface;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityPolicyInterface');
if (\false) {
    class Twig_Sandbox_SecurityPolicyInterface extends \WPML\Core\Twig\Sandbox\SecurityPolicyInterface
    {
    }
}
