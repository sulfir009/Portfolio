<?php

namespace WPML\Core;

use WPML\Core\Twig\Environment;
\class_exists('WPML\\Core\\Twig\\Environment');
if (\false) {
    class Twig_Environment extends \WPML\Core\Twig\Environment
    {
    }
}
