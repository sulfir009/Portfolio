<?php

namespace WPML\Core;

interface ISitePress {}
